package mx.edu.utng.ydeanda.networking;

import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import android.util.Log;
import android.widget.ImageView;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*new DownloadImageTask().execute("http://sonyphotog.com/photos/globalmedicalco/19/93317.jpg");*/
        img = (ImageView) findViewById(R.id.img);
        new DownloadImageTask().execute(
                "http://sonyphotog.com/photos/globalmedicalco/21/100156.jpg",
                "http://sonyphotog.com/photos/globalmedicalco/21/100157.jpg",
                "http://sonyphotog.com/photos/globalmedicalco/19/93321.jpg",
                "http://sonyphotog.com/photos/globalmedicalco/19/93331.jpg",
                "http://sonyphotog.com/photos/globalmedicalco/21/100160.jpg",
                "http://sonyphotog.com/photos/globalmedicalco/21/100154.jpg");
    }

    private InputStream OpenHTTPConnection(String urlString) throws IOException {
        InputStream in = null;
        int response = -1;

        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();

        if (!(conn instanceof HttpURLConnection)) throw new IOException("Not an HTTP Connection");
            try {
                HttpURLConnection httpConn = (HttpURLConnection) conn;
                httpConn.setAllowUserInteraction(false);
                httpConn.setInstanceFollowRedirects(true);
                httpConn.setRequestMethod("GET");
                httpConn.connect();
                response = httpConn.getResponseCode();
                if (response == HttpURLConnection.HTTP_OK) {
                    in = httpConn.getInputStream();
                }
            } catch (Exception ex) {
                Log.d("Networking", ex.getLocalizedMessage());
                throw new IOException("Error connecting");
            }

        return in;
    }

    private Bitmap DownloadImage(String URL){
        Bitmap bitmap = null;
        InputStream in = null;
        try{
            in = OpenHTTPConnection(URL);
            bitmap = BitmapFactory.decodeStream(in);
            in.close();
        }catch (IOException e1){
            Log.d("NetworkingActivity", e1.getLocalizedMessage());
        }
        return bitmap;
    }
    private class DownloadImageTask extends AsyncTask<String, Bitmap, Long>{
        protected Long doInBackground(String... urls){
           long imagesCount = 0;
           for (int i =0; i <urls.length; i++){
               Bitmap imageDownloaded = DownloadImage(urls [i]);
               if(imageDownloaded != null){
                   imagesCount++;
                   try {
                       Thread.sleep(3000);

                   }catch (InterruptedException e){
                       e.printStackTrace();
                   }
                   publishProgress(imageDownloaded);
               }
           }
           return imagesCount;
        }

        protected void onProgressUpdate(Bitmap... bitmap){
            img.setImageBitmap(bitmap[0]);
        }
        protected void onPostExecute (Long imagesDownloaded){
            Toast.makeText(getBaseContext(), "Total "+ imagesDownloaded + " images downloaded", Toast.LENGTH_LONG).show();


        }
    }


    }
